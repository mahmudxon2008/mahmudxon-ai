# Arxitektura

MainActivity (interfeys) -> AssistantService (doimiy xizmat) -> [keyingi bosqichlar]

1-bosqich (shu): loyiha skeleti, interfeys, xizmat, avtomatik ishga tushish.
2-bosqich: Wake word (mikrofon oqimi) -> "Labbay, Mahmudxon!"
3-bosqich: STT (o'zbekcha) va TTS (bulutdagi o'zbekcha ayol ovozi)
4-bosqich: Claude API (onlayn suhbat)
5-bosqich: Telefonni boshqarish (Intent, Accessibility Service)
6-bosqich: Offline buyruqlar, Room xotira, xavfsizlik va tasdiqlar
