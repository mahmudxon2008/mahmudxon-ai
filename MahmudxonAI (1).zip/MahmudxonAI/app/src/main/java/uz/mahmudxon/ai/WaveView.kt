package uz.mahmudxon.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator

/** AI avatari: markaziy shar va ovoz to'lqinlari animatsiyasi. */
class WaveView(context: Context) : View(context) {

    var active = false
        set(value) { field = value; invalidate() }

    private var phase = 0f
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.parseColor("#00E5FF")
    }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = minOf(w, h) * 0.22f
        core.shader = RadialGradient(
            w / 2f, h / 2f, r,
            intArrayOf(Color.parseColor("#B2FFFF"), Color.parseColor("#00B8D4"), Color.parseColor("#01579B")),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) * 0.22f
        val maxR = minOf(width, height) * 0.48f
        val rings = if (active) 4 else 2
        for (i in 0 until rings) {
            val p = (phase + i / rings.toFloat()) % 1f
            ring.alpha = ((1f - p) * (if (active) 220 else 90)).toInt()
            canvas.drawCircle(cx, cy, base + (maxR - base) * p, ring)
        }
        val pulse = if (active) 1f + 0.06f * Math.sin(phase * 2 * Math.PI).toFloat() else 1f
        canvas.drawCircle(cx, cy, base * pulse, core)
    }
}
