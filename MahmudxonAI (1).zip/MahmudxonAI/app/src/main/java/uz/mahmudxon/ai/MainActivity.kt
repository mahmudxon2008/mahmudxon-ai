package uz.mahmudxon.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var wave: WaveView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#0A0F1E"))
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "MAHMUDXON AI"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 22f
            gravity = Gravity.CENTER
        })

        wave = WaveView(this)
        root.addView(wave, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        root.addView(status)

        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        root.addView(toggle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })

        val test = Button(this).apply {
            text = "Ovozni sinash"
            setOnClickListener { speakTest() }
        }
        root.addView(test, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        setContentView(root)
        tts = TextToSpeech(this, this)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun onToggle() {
        if (AssistantService.running) {
            AssistantService.stop(this)
            getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putBoolean("autostart", false).apply()
        } else {
            if (!hasMic()) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                return
            }
            AssistantService.start(this)
            getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putBoolean("autostart", true).apply()
        }
        window.decorView.postDelayed({ refresh() }, 300)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasMic()) onToggle() else toast("Mikrofon ruxsatisiz yordamchi ishlay olmaydi")
    }

    private fun refresh() {
        val on = AssistantService.running
        wave.active = on
        status.text = if (on) "Yordamchi ishlayapti" else "Yordamchi o'chiq"
        toggle.text = if (on) "To'xtatish" else "Yoqish"
    }

    override fun onInit(s: Int) {
        ttsReady = s == TextToSpeech.SUCCESS
    }

    private fun speakTest() {
        val t = tts
        if (!ttsReady || t == null) { toast("Ovoz tizimi tayyor emas"); return }
        val r = t.setLanguage(Locale("uz"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast("Telefonda o'zbekcha ovoz yo'q. 3-bosqichda bulutdagi o'zbekcha ovoz qo'shiladi.")
        } else {
            t.speak("Labbay, Mahmudxon!", TextToSpeech.QUEUE_FLUSH, null, "test")
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
