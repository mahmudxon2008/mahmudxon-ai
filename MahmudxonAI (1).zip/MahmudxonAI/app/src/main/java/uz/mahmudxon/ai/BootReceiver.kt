package uz.mahmudxon.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Telefon qayta yoqilganda yordamchini avtomatik ishga tushiradi (agar yoqilgan bo'lsa). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)
            if (prefs.getBoolean("autostart", false)) {
                AssistantService.start(context)
            }
        }
    }
}
